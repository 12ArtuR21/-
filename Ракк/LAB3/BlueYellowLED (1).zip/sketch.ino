#define LED_BLUE A0
#define LED_YELLOW A1

void setup() {
  pinMode(LED_YELLOW, OUTPUT);
  digitalWrite(LED_YELLOW, LOW);

  pinMode(LED_BLUE, OUTPUT);
  digitalWrite(LED_BLUE, LOW);
}

void loop() {
  digitalWrite(LED_BLUE, HIGH);
  delay(300);
  digitalWrite(LED_BLUE, LOW);
  delay(300);

  digitalWrite(LED_YELLOW, HIGH);
  delay(800);
  digitalWrite(LED_YELLOW, LOW);
  delay(800);
}