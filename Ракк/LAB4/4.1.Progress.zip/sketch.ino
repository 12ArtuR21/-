#include <Wire.h> 
#include <LiquidCrystal_I2C.h> 
// Укажите адрес, количество символов и строк индикатора 
// Для 16x2 дисплея: (адрес, 16, 2) 
// Для 20x4 дисплея: (адрес, 20, 4) 
LiquidCrystal_I2C lcd(0x27, 16, 2);  
void setup() { 
  lcd.init();       
  // Инициализация дисплея 
  lcd.backlight();  // Включение подсветки 
  lcd.setCursor(0, 0); // Ставим курсор на 1-й символ 1-й строки 
  lcd.print("System Loading..."); // Выводим текст 
  lcd.setCursor(0, 1); // Ставим курсор на 1-й символ 2-й строки 
  lcd.print("Please wait"); 
  delay(1000);
  lcd.clear();
  for(int i = 0; i < 11; i+=1){
    lcd.setCursor(0, 0);
    lcd.print("Progress: ");
    lcd.print(i*10);
    lcd.print("%");
    lcd.setCursor(0, 1);
    for(int x = 0; x < i; x++){
      lcd.print("#");
    }
    delay(1000);
    lcd.setCursor(0, 0);
  }
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Load complete");
  lcd.setCursor(0, 1);
  lcd.print("System ready");
} 
void loop() { 
// Здесь код ничего не делает, так как текст не требует обновления 
} 