const int potPin = A0; 
bool isPositive = true;
void setup() { Serial.begin(115200); }
void loop() {
  int sensorValue = analogRead(potPin);
  float voltage = sensorValue * (5.0 / 1023.0);
  Serial.print("Напряжение: ");
  if (!isPositive) Serial.print("-");
  Serial.print(voltage);
  Serial.println(" V");
  if (Serial.available() > 0) {
    char cmd = Serial.read();
    if (cmd == 'P' || cmd == 'p') {
      isPositive = true;
      Serial.println("Знак изменен на +");
    } 
    else if (cmd == 'N' || cmd == 'n') {
      isPositive = false;
      Serial.println("Знак изменен на -");
    }
  }
  delay(5000);
}