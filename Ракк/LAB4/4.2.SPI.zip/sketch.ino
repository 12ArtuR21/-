#include <SPI.h>
#include <SD.h>
#include <Adafruit_GFX.h>
#include <Adafruit_PCD8544.h>

Adafruit_PCD8544 display = Adafruit_PCD8544(13, 11, 10, 9, 8);

void setup() {
  display.begin();
  display.setContrast(50);
  display.clearDisplay();
  display.setCursor(0, 0);
  SD.begin(4);
  if (!SD.exists("test.txt")) {
    File writeFile = SD.open("test.txt", FILE_WRITE);
    if (writeFile) {
      writeFile.print("SPI TEST");
      writeFile.close();
    }
  }
  File myFile = SD.open("test.txt");
  if (myFile) {
    while (myFile.available()) { display.print((char)myFile.read()); }
    myFile.close();
  }
  display.display();
}
void loop() { }